# Fleet Sales Android Prototype
Data source: 18.Pricelist Fleet Update Harga (Perubahan Harga RCA-CC CD)(1).xlsx
Imported products: 1610
Features in this prototype:
- Search part number/product
- Price display
- Qty
- Discount 1-5 applied sequentially
- Automatic total calculation

Open this folder in Android Studio and build the APK.

- PPN 11% otomatis dihitung dari subtotal setelah Diskon 1-5.
- Grand Total = Subtotal + PPN 11%.
