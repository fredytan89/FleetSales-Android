package com.fleetsales.app

import android.app.Activity
import android.os.Bundle
import android.widget.*
import java.io.BufferedReader
import java.io.InputStreamReader
import java.text.NumberFormat
import java.util.Locale
import kotlin.math.roundToLong

data class Product(val category:String,val brand:String,val part:String,val desc:String,val price:Long)

class MainActivity: Activity() {
    private var selected: Product? = null
    private val products = mutableListOf<Product>()
    private val rupiah = NumberFormat.getCurrencyInstance(Locale("id","ID")).apply { maximumFractionDigits=0 }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        loadProducts()
        val search=findViewById<AutoCompleteTextView>(R.id.search)
        val selectedView=findViewById<TextView>(R.id.selected)
        val labels=products.map { "${it.part} | ${it.brand} | ${it.desc}" }
        search.setAdapter(ArrayAdapter(this, android.R.layout.simple_dropdown_item_1line, labels))
        search.threshold=1
        search.setOnItemClickListener { _,_,pos,_ ->
            selected=products[pos]
            val p=selected!!
            selectedView.text="${p.part}\n${p.brand} • ${p.category}\nHarga: ${rupiah.format(p.price)}"
        }
        findViewById<Button>(R.id.calc).setOnClickListener {
            val p=selected ?: run { Toast.makeText(this,"Pilih part number terlebih dahulu",Toast.LENGTH_SHORT).show(); return@setOnClickListener }
            val q=findViewById<EditText>(R.id.qty).text.toString().toDoubleOrNull() ?: 1.0
            val ds=listOf(R.id.d1,R.id.d2,R.id.d3,R.id.d4,R.id.d5).map {
                findViewById<EditText>(it).text.toString().toDoubleOrNull() ?: 0.0
            }
            var net=p.price.toDouble()
            ds.forEach { net *= (1.0-it/100.0) }
            val subtotal=(net*q).roundToLong()
            val ppn=(subtotal * 0.11).roundToLong()
            val grandTotal=subtotal + ppn
            findViewById<TextView>(R.id.result).text="Harga setelah diskon: ${rupiah.format(net.roundToLong())}\\nSubtotal: ${rupiah.format(subtotal)}\\nPPN 11%: ${rupiah.format(ppn)}\\nGRAND TOTAL: ${rupiah.format(grandTotal)}"
        }
    }
    private fun loadProducts(){
        BufferedReader(InputStreamReader(assets.open("products.csv"))).use { br ->
            br.readLine()
            br.lineSequence().forEach { line ->
                val a=line.split(",(?=(?:[^\"]*\"[^\"]*\")*[^\"]*$)".toRegex())
                if(a.size>=5) products.add(Product(a[0],a[1],a[2],a[3],a[4].toDoubleOrNull()?.roundToLong() ?: 0))
            }
        }
    }
}
